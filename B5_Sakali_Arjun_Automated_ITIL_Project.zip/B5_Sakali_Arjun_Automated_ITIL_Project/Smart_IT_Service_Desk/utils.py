import json
import csv
import os

TICKET_FILE = "data/tickets.json"
BACKUP_FILE = "data/backup.csv"


def backup_to_csv():
    if not os.path.exists(TICKET_FILE):
        print("No ticket file found")
        return

    with open(TICKET_FILE, "r") as file:
        tickets = json.load(file)

    if not tickets:
        print("No data to backup")
        return

    keys = tickets[0].keys()

    with open(BACKUP_FILE, "w", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=keys)
        writer.writeheader()
        writer.writerows(tickets)

    print("Backup completed")