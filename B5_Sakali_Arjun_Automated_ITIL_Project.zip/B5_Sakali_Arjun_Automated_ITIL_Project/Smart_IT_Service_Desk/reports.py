import json
import os

TICKET_FILE = "data/tickets.json"


def load_data():
    if not os.path.exists(TICKET_FILE):
        return []

    with open(TICKET_FILE, "r") as file:
        return json.load(file)


def daily_report():
    tickets = load_data()

    total = len(tickets)
    open_tickets = sum(1 for t in tickets if t["status"] == "Open")
    closed_tickets = sum(1 for t in tickets if t["status"] == "Closed")
    high_priority = sum(1 for t in tickets if t["priority"] == "P1")

    print("Daily Report")
    print("Total tickets:", total)
    print("Open tickets:", open_tickets)
    print("Closed tickets:", closed_tickets)
    print("High priority tickets:", high_priority)


def monthly_report():
    tickets = load_data()

    if not tickets:
        print("No data")
        return

    issues = {}
    for t in tickets:
        issue = t["issue"]
        issues[issue] = issues.get(issue, 0) + 1

    most_common = max(issues, key=issues.get)

    dept = {}
    for t in tickets:
        d = t["department"]
        dept[d] = dept.get(d, 0) + 1

    top_dept = max(dept, key=dept.get)

    print("Monthly Report")
    print("Most common issue:", most_common)
    print("Top department:", top_dept)