import json
import os
from datetime import datetime, timedelta
from logger import log_warning

TICKET_FILE = "data/tickets.json"
PROBLEM_FILE = "data/problems.json"

SLA_RULES = {
    "P1": 1,
    "P2": 4,
    "P3": 8,
    "P4": 24
}


def check_sla():
    if not os.path.exists(TICKET_FILE):
        return

    with open(TICKET_FILE, "r") as file:
        tickets = json.load(file)

    now = datetime.now()

    for t in tickets:
        if t["status"] != "Closed":
            created = datetime.strptime(t["created_date"], "%Y-%m-%d %H:%M:%S")
            sla_hours = SLA_RULES.get(t["priority"], 8)

            if now > created + timedelta(hours=sla_hours):
                print(f"SLA Breached for Ticket ID: {t['ticket_id']}")
                log_warning(f"SLA breach for ticket {t['ticket_id']}")


def detect_problem():
    if not os.path.exists(TICKET_FILE):
        return

    with open(TICKET_FILE, "r") as file:
        tickets = json.load(file)

    issue_count = {}

    for t in tickets:
        issue = t["issue"]
        issue_count[issue] = issue_count.get(issue, 0) + 1

    problems = []

    for issue, count in issue_count.items():
        if count >= 5:
            problems.append({
                "issue": issue,
                "count": count,
                "status": "Open"
            })

    with open(PROBLEM_FILE, "w") as file:
        json.dump(problems, file, indent=4)