from tickets import *
from monitor import check_system_health
from itil import check_sla, detect_problem
from reports import daily_report, monthly_report
from utils import backup_to_csv
from logger import setup_logger, log_error


def show_menu():
   
    print("\n")
    print("="*50)
    print("Welcome to Smart IT Service Desk System")
    print("="*50)
    print("Please choose an operation:")
    print("Enter 1 to create a new ticket:")
    print("Enter 2 to view all tickets:")
    print("Enter 3 to search for a ticket:")
    print("Enter 4 to update ticket status:")
    print("Enter 5 to delete a ticket:")
    print("Enter 6 to check system health:")
    print("Enter 7 to check SLA breaches:")
    print("Enter 8 to detect repeated problems:")
    print("Enter 9 to generate daily report:")
    print("Enter 10 to generate monthly report:")
    print("Enter 11 to backup data to CSV:")
    print("Enter 12 to exit:")
    print("="*50)


def main():
    setup_logger()

    while True:
        show_menu()

        try:
            choice = int(input("Enter your choice: "))

            if choice == 1:
                name = input("Enter employee name: ")
                dept = input("Enter department: ")
                issue = input("Describe the issue: ")
                category = input("Enter category: ")

                create_ticket(name, dept, issue, category)

            elif choice == 2:
                view_tickets()

            elif choice == 3:
                ticket_id = int(input("Enter ticket ID: "))
                search_ticket(ticket_id)

            elif choice == 4:
                ticket_id = int(input("Enter ticket ID: "))
                status = input("Enter new status (Open or Closed): ")
                update_ticket(ticket_id, status)

            elif choice == 5:
                ticket_id = int(input("Enter ticket ID: "))
                delete_ticket(ticket_id)

            elif choice == 6:
                check_system_health() 

            elif choice == 7:
                check_sla()       

            elif choice == 8:
                detect_problem()

            elif choice == 9:
                daily_report()

            elif choice == 10:
                monthly_report()

            elif choice == 11:
                backup_to_csv()      

            elif choice == 12:
                print("Exiting system. Thank you.")
                break

            else:
                print("Invalid choice. Please try again.")

        except ValueError:
            print("Invalid input. Please enter correct data.")
        except Exception as e:
            print("Unexpected error occurred:", e)


if __name__ == "__main__":
    main()