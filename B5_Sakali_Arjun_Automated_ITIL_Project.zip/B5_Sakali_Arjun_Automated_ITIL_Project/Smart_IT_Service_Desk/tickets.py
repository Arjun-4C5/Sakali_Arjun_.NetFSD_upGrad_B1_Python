import json
import os
from datetime import datetime
from logger import log_info, log_error   

FILE_PATH = "data/tickets.json"


class Ticket:
    ticket_counter = 1

    def __init__(self, name, department, issue, category):
        self.ticket_id = Ticket.ticket_counter
        Ticket.ticket_counter += 1

        self.name = name
        self.department = department
        self.issue = issue
        self.category = category

        self.priority = self.set_priority(issue)
        self.status = "Open"
        self.created_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def set_priority(self, issue):
        issue = issue.lower()

        if "server down" in issue:
            return "P1"
        elif "internet down" in issue:
            return "P2"
        elif "laptop slow" in issue:
            return "P3"
        elif "password reset" in issue:
            return "P4"
        else:
            return "P3"

    def to_dict(self):
        return self.__dict__

def load_tickets():
    if not os.path.exists(FILE_PATH):
        return []

    try:
        with open(FILE_PATH, "r") as file:
            data = file.read().strip()
            if not data:
                return []
            return json.loads(data)
    except Exception as e:
        log_error(f"Error loading tickets: {e}")
        return []

def save_tickets(tickets):
    try:
        with open(FILE_PATH, "w") as file:
            json.dump(tickets, file, indent=4)
    except Exception as e:
        log_error(f"Error saving tickets: {e}")

def create_ticket(name, department, issue, category):
    tickets = load_tickets()

    ticket = Ticket(name, department, issue, category)
    tickets.append(ticket.to_dict())

    save_tickets(tickets)
    print("Ticket created successfully")
    log_info(f"Ticket created with ID {ticket.ticket_id}")

def view_tickets():
    tickets = load_tickets()

    if not tickets:
        print("No tickets found")
        return

    for t in tickets:
        print(t)

def search_ticket(ticket_id):
    tickets = load_tickets()

    for t in tickets:
        if t["ticket_id"] == ticket_id:
            print("Ticket Found:", t)
            return

    print("Ticket not found")
    log_error(f"Search failed for ticket {ticket_id}")

def update_ticket(ticket_id, new_status):
    tickets = load_tickets()

    for t in tickets:
        if t["ticket_id"] == ticket_id:
            t["status"] = new_status
            save_tickets(tickets)
            print("Ticket updated")
            log_info(f"Ticket {ticket_id} updated to {new_status}")
            return

    print("Ticket not found")
    log_error(f"Update failed for ticket {ticket_id}")


def delete_ticket(ticket_id):
    tickets = load_tickets()

    new_tickets = [t for t in tickets if t["ticket_id"] != ticket_id]

    if len(new_tickets) == len(tickets):
        print("Ticket not found")
        log_error(f"Delete failed for ticket {ticket_id}")
        return

    save_tickets(new_tickets)
    print("Ticket deleted")
    log_info(f"Ticket {ticket_id} deleted")