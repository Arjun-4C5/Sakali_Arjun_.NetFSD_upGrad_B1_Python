import psutil
from tickets import create_ticket
from logger import log_warning

def check_system_health():
    cpu = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory().percent
    disk = psutil.disk_usage('/').percent

    print(f"CPU Usage: {cpu}%")
    print(f"Memory Usage: {memory}%")
    print(f"Disk Usage: {disk}%")

    if cpu > 90:
        create_ticket("System", "IT", "High CPU Usage", "Monitoring")
        log_warning("High CPU usage detected")

    if memory > 95:
        create_ticket("System", "IT", "High Memory Usage", "Monitoring")
        log_warning("High Memory usage detected")

    if disk > 90:
        create_ticket("System", "IT", "Disk Almost Full", "Monitoring")
        log_warning("Low disk space detected")