Smart IT Service Desk System

This project automates IT helpdesk operations using Python.

Features:
- Ticket Management
- SLA Tracking
- System Monitoring
- Logging
- Reports
- Backup System

Technologies:
- Python
- JSON
- CSV
- psutil

How to Run:
python main.py